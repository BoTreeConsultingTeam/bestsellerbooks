require 'test_helper'

class ScrappersHelperTest < ActionView::TestCase
end
