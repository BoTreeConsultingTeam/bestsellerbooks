# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Bestsellerbooks::Application.config.secret_token = '872202ebecdc378f18b22f87d8c0fba62c8ca1f438073d8f57566e5d2dd4205a2e84055c5e25c7f2ac58af4ecb51601264af05c23e9bc24cd3c998357e49d641'
