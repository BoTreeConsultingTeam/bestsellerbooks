module ScrappersHelper
end
