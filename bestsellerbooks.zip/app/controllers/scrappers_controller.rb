class ScrappersController < ApplicationController
  def show_latest_books
    @crossword = Utilities::Scrappers::Scrapper.create_new_crossword_scrapper
    @landmark = Utilities::Scrappers::Scrapper.create_new_landmark_scrapper
    @flipkart = Utilities::Scrappers::Scrapper.create_new_flipkart_scrapper
    @infibeam = Utilities::Scrappers::Scrapper.create_new_infibeam_scrapper

    @crossword.process_page
    @landmark.process_page
    @flipkart.process_page
    @infibeam.process_page

    @crossword_data = @crossword.book_details
    @landmark_data = @landmark.book_details
    @flipkart_data = @flipkart.book_details
    @infibeam_data = @infibeam.book_details
    @data = @crossword_data + @landmark_data + @flipkart_data + @infibeam_data
  end
end

